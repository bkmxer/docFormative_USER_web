App - development version;
Dist - prod version;

## in order to start local dev server and compile App into Dev ##
1) run npm install
2) gulp watch - will start a server
2) gulp build - compile the prod version